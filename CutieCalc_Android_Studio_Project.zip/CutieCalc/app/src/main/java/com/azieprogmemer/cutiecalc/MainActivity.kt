package com.azieprogmemer.cutiecalc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.BigDecimal
import java.math.MathContext

private val Pink = Color(0xFFFF8FB1)
private val DeepPink = Color(0xFFE85D91)
private val Lavender = Color(0xFFEDE7FF)
private val Cream = Color(0xFFFFF9F4)
private val Ink = Color(0xFF493D52)
private val Night = Color(0xFF241E2B)
private val NightCard = Color(0xFF352B40)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CutieCalcApp() }
    }
}

@Composable
fun CutieCalcApp() {
    var expression by remember { mutableStateOf("") }
    var display by remember { mutableStateOf("0") }
    var dark by remember { mutableStateOf(false) }
    var justEvaluated by remember { mutableStateOf(false) }

    val bg = if (dark) Night else Cream
    val card = if (dark) NightCard else Color.White
    val text = if (dark) Color(0xFFFFF2FA) else Ink
    val soft = if (dark) Color(0xFF4A3A54) else Lavender

    fun press(value: String) {
        when (value) {
            "AC" -> { expression = ""; display = "0"; justEvaluated = false }
            "⌫" -> {
                if (justEvaluated) { expression = ""; display = "0"; justEvaluated = false }
                else {
                    expression = expression.dropLast(1)
                    display = expression.ifBlank { "0" }
                }
            }
            "=" -> {
                val result = calculate(expression)
                if (result != null) {
                    display = result
                    expression = result
                    justEvaluated = true
                } else {
                    display = "Oops! ✿"
                    justEvaluated = true
                }
            }
            else -> {
                if (justEvaluated) {
                    if (value in listOf("+", "−", "×", "÷", "%")) {
                        expression = display
                    } else {
                        expression = ""
                    }
                    justEvaluated = false
                }
                expression += value
                display = expression
            }
        }
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = bg) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("cutie calc ✿", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = text)
                        Text("little numbers, big magic", fontSize = 13.sp, color = if (dark) Pink else DeepPink)
                    }
                    IconButton(onClick = { dark = !dark }) {
                        Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle theme", tint = if (dark) Pink else DeepPink)
                    }
                }

                Column(
                    modifier = Modifier.fillMaxWidth().weight(1f)
                        .shadow(6.dp, RoundedCornerShape(30.dp))
                        .background(card, RoundedCornerShape(30.dp))
                        .padding(22.dp),
                    verticalArrangement = Arrangement.Bottom,
                    horizontalAlignment = Alignment.End
                ) {
                    Text(if (expression.isBlank()) "your answer goes here ♡" else expression,
                        color = if (dark) Color(0xFFC9B9D4) else Color(0xFF9B8AA3),
                        fontSize = 17.sp, textAlign = TextAlign.End, maxLines = 2)
                    Spacer(Modifier.height(12.dp))
                    Text(display, color = text, fontSize = if (display.length > 12) 34.sp else 46.sp,
                        fontWeight = FontWeight.Bold, textAlign = TextAlign.End, maxLines = 2)
                    Spacer(Modifier.height(18.dp))
                    Text("♡  ✧  ♡", color = Pink, fontSize = 18.sp)
                }

                val rows = listOf(
                    listOf("AC", "⌫", "%", "÷"),
                    listOf("7", "8", "9", "×"),
                    listOf("4", "5", "6", "−"),
                    listOf("1", "2", "3", "+"),
                    listOf("±", "0", ".", "=")
                )
                rows.forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { key ->
                            val isOperator = key in listOf("÷", "×", "−", "+", "=")
                            val isSpecial = key in listOf("AC", "⌫", "%", "±")
                            val fill = when {
                                key == "=" -> DeepPink
                                isOperator -> Pink
                                isSpecial -> soft
                                else -> card
                            }
                            val foreground = when {
                                key == "=" || isOperator -> Color.White
                                else -> text
                            }
                            Surface(
                                onClick = {
                                    if (key == "±") {
                                        if (expression.isNotBlank()) {
                                            expression = if (expression.startsWith("-")) expression.drop(1) else "-$expression"
                                            display = expression
                                        }
                                    } else press(key)
                                },
                                modifier = Modifier.weight(1f).height(64.dp),
                                shape = RoundedCornerShape(22.dp),
                                color = fill,
                                shadowElevation = if (key == "=") 5.dp else 1.dp
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (key == "⌫") {
                                        Icon(Icons.Default.Backspace, contentDescription = "Delete last character", tint = foreground)
                                    } else {
                                        Text(key, fontSize = if (key.length > 1) 18.sp else 23.sp,
                                            fontWeight = FontWeight.Bold, color = foreground)
                                    }
                                }
                            }
                        }
                    }
                }
                Text("made with love and a little sparkle ✧", modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center, fontSize = 11.sp, color = if (dark) Color(0xFFB9A6C7) else Color(0xFFB29EAF))
            }
        }
    }
}

private fun calculate(raw: String): String? {
    if (raw.isBlank()) return null
    return try {
        val normalized = raw.replace("×", "*").replace("÷", "/").replace("−", "-")
        val tokens = Regex("""\d+(?:\.\d+)?|[+\-*/%]""").findAll(normalized).map { it.value }.toList()
        if (tokens.joinToString("") != normalized.replace(" ", "")) return null
        val values = mutableListOf<Double>()
        val ops = mutableListOf<String>()
        var expectNumber = true
        for (token in tokens) {
            if (token.toDoubleOrNull() != null) {
                values.add(token.toDouble())
                expectNumber = false
            } else {
                if (expectNumber && token == "-" && values.isEmpty()) {
                    values.add(0.0); ops.add("-")
                } else {
                    if (expectNumber || values.size != ops.size + 1) return null
                    ops.add(token)
                    expectNumber = true
                }
            }
        }
        if (expectNumber || values.size != ops.size + 1) return null

        // Standard precedence: multiplication, division and percentage first, then addition/subtraction.
        var i = 0
        while (i < ops.size) {
            val op = ops[i]
            if (op == "*" || op == "/" || op == "%") {
                val a = values[i]
                val b = values[i + 1]
                val result = when (op) {
                    "*" -> a * b
                    "/" -> if (b == 0.0) return null else a / b
                    else -> a % b
                }
                values[i] = result
                values.removeAt(i + 1)
                ops.removeAt(i)
            } else i++
        }
        var result = values[0]
        for (j in ops.indices) result = if (ops[j] == "+") result + values[j + 1] else result - values[j + 1]
        if (!result.isFinite()) return null
        BigDecimal.valueOf(result).stripTrailingZeros().toPlainString()
    } catch (_: Exception) { null }
}
