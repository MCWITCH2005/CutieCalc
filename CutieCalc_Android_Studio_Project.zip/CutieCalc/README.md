# Cutie Calc ✿

A cute pastel Android calculator built with Kotlin and Jetpack Compose.

## Included
- Pink, lavender, and cream UI
- Light/dark theme toggle
- Basic arithmetic, decimal input, remainder, clear, and backspace
- Offline operation; no permissions or network access requested
- App ID: `com.azieprogmemer.cutiecalc`

## Open in Android Studio
1. Install the latest stable Android Studio and Android SDK Platform 36.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `CutieCalc` folder.
4. Allow Gradle to sync. If prompted, install the Android Gradle Plugin / SDK components.
5. Run on an Android emulator or connect your Android phone with USB debugging enabled.

## Create a Google Play upload bundle (AAB)
1. In Android Studio, open **Build → Generate Signed Bundle / APK**.
2. Select **Android App Bundle**.
3. Create a new upload key/keystore and store it somewhere safe. Never share it or commit it to public repositories.
4. Choose the `release` build variant and finish the wizard.
5. Upload the generated `.aab` to Google Play Console and complete the store listing, app-content, privacy, and testing requirements.

## Before publishing
- Change the application ID if you want a different permanent package name. Once published, changing it creates a different app.
- Add a polished launcher icon and store screenshots.
- Test calculations thoroughly on real devices.
- Google Play may require a specific target API level and testing steps for your developer account at publishing time; verify current requirements in Play Console.
- This source project is not a signed APK/AAB. Signing is done with your private upload key in Android Studio.
